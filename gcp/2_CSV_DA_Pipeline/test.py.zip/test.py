webserver="222"
clientid="33"

line1="webserver = " + "\""+ webserver  + "\""
line2="clientid = " +  "\""+ clientid +  "\""

print("TEST is Applied")

